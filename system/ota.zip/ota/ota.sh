#!/bin/sh
chmod 775 -R /tmp/ota

mv /tmp/ota/bin/media_sample /system/bin/media_sample
mv /tmp/ota/init/app_init.sh /system/init/app_init.sh
mv /tmp/ota/init/ota_run.sh  /system/init/ota_run.sh
mv /tmp/ota/init/backup/*    /system/init/backup/
mv /tmp/ota/sd_insert.sh /system/etc/mdev/sd_insert.sh
mv /tmp/ota/etc/sensor/sc4238-t31.bin /system/etc/sensor/sc4238-t31.bin
mv /tmp/ota/lib/libjz_faceDet.so /system/lib/libjz_faceDet.so
mv /tmp/ota/lib/libjzdl.m.so     /system/lib/libjzdl.m.so
mv /tmp/ota/lib/libjzdl.so       /system/lib/libjzdl.so

chmod a+x /system/bin/media_sample
chmod a+x /system/init/app_init.sh
chmod a+x /system/init/ota_run.sh
chmod a+x /system/init/backup/app_init.sh
chmod a+x /system/etc/mdev/sd_insert.sh
chmod a+x /system/etc/sensor/sc4238-t31.bin
